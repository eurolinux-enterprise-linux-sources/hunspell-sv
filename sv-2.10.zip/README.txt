This Swedish Dictionary for Spell Checking is maintained by
Göran Andersson <goran@init.se>.

Copyright © 2003-2012 Göran Andersson <goran@init.se>.

This dictionary is made available subject to the terms of GNU Lesser General Public License Version 3. A copy of the LGPL license can be found at http://www.gnu.org/licenses/lgpl-3.0.html .
